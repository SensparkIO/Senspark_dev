#ifndef senspark_H
#define senspark_H

#include "Arduino.h"

#include <ESP8266WiFi.h>
#include <ESP8266WiFi.h>
#include<ESP8266WebServer.h>
#include <WiFiClientSecure.h>
#include <ESP8266HTTPClient.h>
#include <ESP8266httpUpdate.h>
#include <SocketIoClient.h>
#include<EEPROM.h>


class senspark
{
    public : 
    senspark(int pin, String apikey);
    void initialize();
    void setupAP();
    void launchWeb(int webstype);
    void createWebServer(int webtype);
    void listenServer();
    boolean listenSocket();
    void establishSocket();
    void collectdata(int mint, float f1);
    void collectdata(int mint, float f1, float f2);
    void collectdata(int mint, float f1, float f2);
    void collectdata(int mint, float f1, float f2, float f3);
    void collectdata(int mint, float f1, float f2, float f3, float f4);
    void collectdata(int mint, float f1, float f2, float f3, float f4, float f5);
    void collectdata(int mint, float f1, float f2, float f3, float f4, float f5, float f6);
    void collectdata(int mint, float f1, float f2, float f3, float f4, float f5, float f6, float f7);
    void collectdata(int mint, float f1, float f2, float f3, float f4, float f5, float f6, float f7, float f8);
    void collectdata(int mint, float f1, float f2, float f3, float f4, float f5, float f6, float f7, float f8, float f9);
    void collectdata(int mint, float f1, float f2, float f3, float f4, float f5, float f6, float f7, float f8, float f9, float f10);
    void pushLive(int mint, float f1);
    void pushLive(int mint, float f1, float f2);
    void pushLive(int mint, float f1, float f2, float f3);
    void pushLive(int mint, float f1, float f2, float f3, float f4);
    void pushLive(int mint, float f1, float f2, float f3, float f4, float f5);
    void pushLive(int mint, float f1, float f2, float f3, float f4, float f5, float f6);
    void pushLive(int mint, float f1, float f2, float f3, float f4, float f5, float f6, float f7);
    void pushLive(int mint, float f1, float f2, float f3, float f4, float f5, float f6, float f7, float f8);
    void pushLive(int mint, float f1, float f2, float f3, float f4, float f5, float f6, float f7, float f8, float f9);
    void pushLive(int mint, float f1, float f2, float f3, float f4, float f5, float f6, float f7, float f8, float f9, float f10);
    int _pin;
    String _apikey;
    

};
#endif