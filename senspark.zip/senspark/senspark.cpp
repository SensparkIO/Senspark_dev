#include "senspark.h"
#include "Arduino.h"
#include "ESP8266WiFi.h"
#include <ESP8266WiFi.h>
#include<ESP8266WebServer.h>
#include <WiFiClientSecure.h>
#include <ESP8266HTTPClient.h>
#include <ESP8266httpUpdate.h>
#include <SocketIoClient.h>
#include<EEPROM.h>


ESP8266WebServer server(80);
unsigned long lastMillis;
int statusCode;
String st;
String content;
int serverstat=0;
int check=0;
int wifistatus=0;
int k= 0;
String sendapikey;
SocketIoClient webSocket;
senspark::senspark(int pin, String apikey)
{
    _pin = pin;
    _apikey = apikey;
    sendapikey = _apikey;
}
void senspark::initialize()
{
    String ssid;
    String pass;
  EEPROM.begin(512);
    Serial.println("Starting");
    Serial.println("Reading ssid and password from EEPROM");
    for(int i= 0 ; i < 32; i ++)
    {
      
        ssid += char(EEPROM.read(i));
    }
    Serial.println("SSID:" +  ssid);
    for(int i=32;i<96;i++)
    {
        pass += char(EEPROM.read(i));
    }
    Serial.println("Password:" +  pass);
    if(EEPROM.read(0)!=255)
    {
      int i = 0;
        WiFi.begin(ssid, pass);
        while(WiFi.status() != WL_CONNECTED && i<45)
        {
          
            Serial.println("Connecting...");
            delay(1000);
            i++;
        }
        if(WiFi.status()!=WL_CONNECTED)
            {
              setupAP();
            }
            else{
        Serial.println("Connected");
        //webSocket.begin("api.senspark.io", 3000, "/socket.io/?transport=websocket");
        establishSocket();
            }
    }
    else
    {
       Serial.println("Opening server"); 
       setupAP();
    }
}
void senspark:: pushLive(int mint, float f1){
  
      float field1 = f1;
      String jsonobj = "\"field1:";
      jsonobj += f1;
      jsonobj += "\"";
      const char* jobj = jsonobj.c_str();
      webSocket.emit("track-data", jobj);
}
void senspark:: pushLive(int mint, float f1, float f2){
  
      String jsonobj = "\"field1:";
      jsonobj += f1;
      jsonobj += ",";
      jsonobj += "field2:";
      jsonobj += f2;
      jsonobj += "\"";
      const char* jobj = jsonobj.c_str();
      webSocket.emit("track-data", jobj);
}
void senspark:: pushLive(int mint, float f1, float f2, float f3){
  
      String jsonobj = "\"field1:";
      jsonobj += f1;
      jsonobj += ",";
      jsonobj += "field2:";
      jsonobj += f2;
      jsonobj += ",";
      jsonobj += "field3:";
      jsonobj += f3;
      jsonobj += "\"";
      const char* jobj = jsonobj.c_str();
      webSocket.emit("track-data", jobj);
}
void senspark:: pushLive(int mint, float f1, float f2, float f3, float f4){
  
      String jsonobj = "\"field1:";
      jsonobj += f1;
      jsonobj += ",";
      jsonobj += "field2:";
      jsonobj += f2;
      jsonobj += ",";
      jsonobj += "field3:";
      jsonobj += f3;
      jsonobj += ",";
      jsonobj += "field4:";
      jsonobj += f4;
      jsonobj += "\"";
      const char* jobj = jsonobj.c_str();
      webSocket.emit("track-data", jobj);
}
void senspark:: pushLive(int mint, float f1, float f2, float f3, float f4, float f5){
  
      String jsonobj = "\"field1:";
      jsonobj += f1;
      jsonobj += ",";
      jsonobj += "field2:";
      jsonobj += f2;
      jsonobj += ",";
      jsonobj += "field3:";
      jsonobj += f3;
      jsonobj += ",";
      jsonobj += "field4:";
      jsonobj += f4;
      jsonobj += ",";
      jsonobj += "field5:";
      jsonobj += f5;
      jsonobj += "\"";
      const char* jobj = jsonobj.c_str();
      webSocket.emit("track-data", jobj);
}
void senspark:: pushLive(int mint, float f1, float f2, float f3, float f4, float f5, float f6){
  
      String jsonobj = "\"field1:";
      jsonobj += f1;
      jsonobj += ",";
      jsonobj += "field2:";
      jsonobj += f2;
      jsonobj += ",";
      jsonobj += "field3:";
      jsonobj += f3;
      jsonobj += ",";
      jsonobj += "field4:";
      jsonobj += f4;
      jsonobj += ",";
      jsonobj += "field5:";
      jsonobj += f5;
      jsonobj += ",";
      jsonobj += "field6:";
      jsonobj += f6;
      jsonobj += "\"";
      const char* jobj = jsonobj.c_str();
      webSocket.emit("track-data", jobj);
}
void senspark:: pushLive(int mint, float f1, float f2, float f3, float f4, float f5, float f6, float f7){
  
      String jsonobj = "\"field1:";
      jsonobj += f1;
      jsonobj += ",";
      jsonobj += "field2:";
      jsonobj += f2;
      jsonobj += ",";
      jsonobj += "field3:";
      jsonobj += f3;
      jsonobj += ",";
      jsonobj += "field4:";
      jsonobj += f4;
      jsonobj += ",";
      jsonobj += "field5:";
      jsonobj += f5;
      jsonobj += ",";
      jsonobj += "field6:";
      jsonobj += f6;
      jsonobj += ",";
      jsonobj += "field7:";
      jsonobj += f7;
      jsonobj += "\"";
      const char* jobj = jsonobj.c_str();
      webSocket.emit("track-data", jobj);
}
void senspark:: pushLive(int mint, float f1, float f2, float f3, float f4, float f5, float f6, float f7, float f8){
  
      String jsonobj = "\"field1:";
      jsonobj += f1;
      jsonobj += ",";
      jsonobj += "field2:";
      jsonobj += f2;
      jsonobj += ",";
      jsonobj += "field3:";
      jsonobj += f3;
      jsonobj += ",";
      jsonobj += "field4:";
      jsonobj += f4;
      jsonobj += ",";
      jsonobj += "field5:";
      jsonobj += f5;
      jsonobj += ",";
      jsonobj += "field6:";
      jsonobj += f6;
      jsonobj += ",";
      jsonobj += "field7:";
      jsonobj += f7;
      jsonobj += ",";
      jsonobj += "field8:";
      jsonobj += f8;
      jsonobj += "\"";
      const char* jobj = jsonobj.c_str();
      webSocket.emit("track-data", jobj);
}
void senspark:: pushLive(int mint, float f1, float f2, float f3, float f4, float f5, float f6, float f7, float f8, float f9){
  
      String jsonobj = "\"field1:";
      jsonobj += f1;
      jsonobj += ",";
      jsonobj += "field2:";
      jsonobj += f2;
      jsonobj += ",";
      jsonobj += "field3:";
      jsonobj += f3;
      jsonobj += ",";
      jsonobj += "field4:";
      jsonobj += f4;
      jsonobj += ",";
      jsonobj += "field5:";
      jsonobj += f5;
      jsonobj += ",";
      jsonobj += "field6:";
      jsonobj += f6;
      jsonobj += ",";
      jsonobj += "field7:";
      jsonobj += f7;
      jsonobj += ",";
      jsonobj += "field8:";
      jsonobj += f8;
      jsonobj += ",";
      jsonobj += "field9:";
      jsonobj += f9;
      jsonobj += "\"";
      const char* jobj = jsonobj.c_str();
      webSocket.emit("track-data", jobj);
}
void senspark:: pushLive(int mint, float f1, float f2, float f3, float f4, float f5, float f6, float f7, float f8, float f9, float f10){
  
      String jsonobj = "\"field1:";
      jsonobj += f1;
      jsonobj += ",";
      jsonobj += "field2:";
      jsonobj += f2;
      jsonobj += ",";
      jsonobj += "field3:";
      jsonobj += f3;
      jsonobj += ",";
      jsonobj += "field4:";
      jsonobj += f4;
      jsonobj += ",";
      jsonobj += "field5:";
      jsonobj += f5;
      jsonobj += ",";
      jsonobj += "field6:";
      jsonobj += f6;
      jsonobj += ",";
      jsonobj += "field7:";
      jsonobj += f7;
      jsonobj += ",";
      jsonobj += "field8:";
      jsonobj += f8;
      jsonobj += ",";
      jsonobj += "field9:";
      jsonobj += f9;
      jsonobj += ",";
      jsonobj += "field10:";
      jsonobj += f10;
      jsonobj += "\"";
      const char* jobj = jsonobj.c_str();
      webSocket.emit("track-data", jobj);
}
void create_room(const char* state, size_t length){
webSocket.emit("device-id", sendapikey.c_str());
}
 void listenRequest(const char* state, size_t length)
 {
   Serial.println(state);
  if (strcmp(state, ("{\"state\":true}")) == 0) {
    k=1;
  }
 }
std::function<void (const char * payload, size_t length)> func1 = create_room;
std::function<void (const char * payload, size_t length)> func2 = listenRequest;
void senspark::establishSocket(){
  Serial.println("establishing socket now");
  delay(1000);
  webSocket.begin("api.senspark.io", 3000, "/socket.io/?transport=websocket");
    delay(500);
    check=1;
    
    webSocket.on("light", func2);
    webSocket.on("connect", func1);
    
    
}

void senspark::setupAP(){
    WiFi.mode(WIFI_STA);
  WiFi.disconnect();
  delay(100);
  int n = WiFi.scanNetworks();
  Serial.println("scan done");
  if (n == 0)
    Serial.println("no networks found");
  else
  {
    Serial.print(n);
    Serial.println(" networks found");
    for (int i = 0; i < n; ++i)
     {
      // Print SSID and RSSI for each network found
      Serial.print(i + 1);
      Serial.print(": ");
      Serial.print(WiFi.SSID(i));
      Serial.print(" (");
      Serial.print(WiFi.RSSI(i));
      Serial.print(")");
      Serial.println((WiFi.encryptionType(i) == ENC_TYPE_NONE)?" ":"*");
      delay(10);
     }
  }
  Serial.println(""); 
  st = "<ol>";
  for (int i = 0; i < n; ++i)
    {
      // Print SSID and RSSI for each network found
      st += "<li>";
      st += WiFi.SSID(i);
      st += " (";
      st += WiFi.RSSI(i);
      st += ")";
      st += (WiFi.encryptionType(i) == ENC_TYPE_NONE)?" ":"*";
      st += "</li>";
    }
  st += "</ol>";
  delay(100);
  WiFi.softAP("deX");
  Serial.println("softap");
   serverstat=1;
  launchWeb(1);
  Serial.println("over");
}
void senspark::launchWeb(int webtype){
  Serial.println("");
  Serial.println("WiFi connected");
  Serial.print("Local IP: ");
  Serial.println(WiFi.localIP());
  Serial.print("SoftAP IP: ");
  Serial.println(WiFi.softAPIP());
  createWebServer(webtype);
  // Start the server
  server.begin();
  Serial.println("Server started"); 
  wifistatus=0;
}
void senspark::createWebServer(int webtype)
{
    if ( webtype == 1 ) {
    server.on("/", []() {
        IPAddress ip = WiFi.softAPIP();
        String ipStr = String(ip[0]) + '.' + String(ip[1]) + '.' + String(ip[2]) + '.' + String(ip[3]);
        content = "<!DOCTYPE HTML>\r\n<html>Hello from ESP8266 at ";
        content += ipStr;
        content += "<p>";
        content += st;
        content += "</p><form method='get' action='setting'><label>SSID: </label><input name='arg0' length=20><label>Pass: </label><input name='arg1' length=46><label>Project ID: </label><input name='arg2' length=30><label>Device ID: </label><input name='arg3' length=30><input type='submit'></form>";
        content += "</html>";
        server.send(200, "text/html", content);  
    });
    server.on("/setting", []() {
        String qsid = server.arg("arg0");
        String qpass = server.arg("arg1");
        String projectid = server.arg("arg2");
        String deviceid = server.arg("arg3");
        if (qsid.length() > 0 && qpass.length() > 0) {
          Serial.println("clearing eeprom");
          for (int i = 0; i < 96; ++i) { EEPROM.write(i, 0); }
          Serial.println(qsid);
          Serial.println("");
          Serial.println(qpass);
          Serial.println("");
            
          Serial.println("writing eeprom ssid:");
          for (unsigned i = 0; i < qsid.length(); i++)
            {
              EEPROM.write(i, qsid[i]);
              Serial.print("Wrote: ");
              Serial.println(qsid[i]); 
            }
          Serial.println("writing eeprom pass:"); 
          for (unsigned i = 0; i < qpass.length(); ++i)
            {
              EEPROM.write(32+i, qpass[i]);
              Serial.print("Wrote: ");
              Serial.println(qpass[i]); 
            }    
            for (unsigned i = 0; i < deviceid.length(); ++i)
            {
              EEPROM.write(108+i, deviceid[i]);
              Serial.print("Wrote: ");
              Serial.println(deviceid[i]); 
            }    
          EEPROM.commit();
          content = "{\"Success\":\"saved to eeprom... reset to boot into new wifi\"}";
          statusCode = 200;
          delay(1000);
        } else {
          content = "{\"Error\":\"404 not found\"}";
          statusCode = 404;
          Serial.println("Sending 404");
        }
        server.send(statusCode, "application/json", content);
        delay(1000);
         
    ESP.restart();
    });
   
  }
}
void senspark::listenServer(){
    if(serverstat==1){
  server.handleClient();
  }
}
boolean senspark::listenSocket(){
  if(check == 1)
  {
    webSocket.loop();
  }
  if(k==1)
  {
    k=0;
    return true;
  }
  else return false;
}
void senspark:: collectdata(int mint, float f1)
{
  if (millis() - lastMillis >= mint * 60 * 1000UL)
  {
      lastMillis = millis(); 
      String jsonobj = "\"field1:";
      jsonobj += f1;
      jsonobj += "\"";
      const char* jobj = jsonobj.c_str();
      webSocket.emit("track-data", jobj);
  }
}
void senspark:: collectdata(int mint, float f1, float f2)
{
  if (millis() - lastMillis >= mint * 60 * 1000UL)
  {
      lastMillis = millis(); 
      String jsonobj = "\"field1:";
      jsonobj += f1;
      jsonobj += ",";
      jsonobj += "field2:";
      jsonobj += f2;
      jsonobj += "\"";
      const char* jobj = jsonobj.c_str();
      webSocket.emit("track-data", jobj);
  }
}
void senspark:: collectdata(int mint, float f1, float f2, float f3)
{
  if (millis() - lastMillis >= mint * 60 * 1000UL)
  {
      lastMillis = millis(); 
      String jsonobj = "\"field1:";
      jsonobj += f1;
      jsonobj += ",";
      jsonobj += "field2:";
      jsonobj += f2;
      jsonobj += ",";
      jsonobj += "field3:";
      jsonobj += f3;
      jsonobj += "\"";
      const char* jobj = jsonobj.c_str();
      webSocket.emit("track-data", jobj);
  }
}
void senspark:: collectdata(int mint, float f1, float f2, float f3, float f4)
{
  if (millis() - lastMillis >= mint * 60 * 1000UL)
  {
      lastMillis = millis(); 
      String jsonobj = "\"field1:";
      jsonobj += f1;
      jsonobj += ",";
      jsonobj += "field2:";
      jsonobj += f2;
      jsonobj += ",";
      jsonobj += "field3:";
      jsonobj += f3;
      jsonobj += ",";
      jsonobj += "field4:";
      jsonobj += f4;
      jsonobj += "\"";
      const char* jobj = jsonobj.c_str();
      webSocket.emit("track-data", jobj);
  }
}
void senspark:: collectdata(int mint, float f1, float f2, float f3, float f4, float f5)
{
  if (millis() - lastMillis >= mint * 60 * 1000UL)
  {
      lastMillis = millis(); 
      String jsonobj = "\"field1:";
      jsonobj += f1;
      jsonobj += ",";
      jsonobj += "field2:";
      jsonobj += f2;
      jsonobj += ",";
      jsonobj += "field3:";
      jsonobj += f3;
      jsonobj += ",";
      jsonobj += "field4:";
      jsonobj += f4;
       jsonobj += ",";
      jsonobj += "field5:";
      jsonobj += f5;
      jsonobj += "\"";
      const char* jobj = jsonobj.c_str();
      webSocket.emit("track-data", jobj);
  }
}
void senspark:: collectdata(int mint, float f1, float f2, float f3, float f4, float f5, float f6)
{
  if (millis() - lastMillis >= mint * 60 * 1000UL)
  {
      lastMillis = millis(); 
      String jsonobj = "\"field1:";
      jsonobj += f1;
      jsonobj += ",";
      jsonobj += "field2:";
      jsonobj += f2;
      jsonobj += ",";
      jsonobj += "field3:";
      jsonobj += f3;
      jsonobj += ",";
      jsonobj += "field4:";
      jsonobj += f4;
      jsonobj += ",";
      jsonobj += "field5:";
      jsonobj += f5;
      jsonobj += ",";
      jsonobj += "field6:";
      jsonobj += f6;
      jsonobj += "\"";
      const char* jobj = jsonobj.c_str();
      webSocket.emit("track-data", jobj);
  }
}
void senspark:: collectdata(int mint, float f1, float f2, float f3, float f4, float f5, float f6,float f7)
{
  if (millis() - lastMillis >= mint * 60 * 1000UL)
  {
      lastMillis = millis(); 
      String jsonobj = "\"field1:";
      jsonobj += f1;
      jsonobj += ",";
      jsonobj += "field2:";
      jsonobj += f2;
      jsonobj += ",";
      jsonobj += "field3:";
      jsonobj += f3;
      jsonobj += ",";
      jsonobj += "field4:";
      jsonobj += f4;
       jsonobj += ",";
      jsonobj += "field5:";
      jsonobj += f5;
      jsonobj += ",";
      jsonobj += "field6:";
      jsonobj += f6;
      jsonobj += ",";
      jsonobj += "field7:";
      jsonobj += f7;
      jsonobj += "\"";
      const char* jobj = jsonobj.c_str();
      webSocket.emit("track-data", jobj);
  }
}
void senspark:: collectdata(int mint, float f1, float f2, float f3, float f4, float f5, float f6,float f7, float f8)
{
  if (millis() - lastMillis >= mint * 60 * 1000UL)
  {
      lastMillis = millis();
      String jsonobj = "\"field1:";
      jsonobj += f1;
      jsonobj += ",";
      jsonobj += "field2:";
      jsonobj += f2;
      jsonobj += ",";
      jsonobj += "field3:";
      jsonobj += f3;
      jsonobj += ",";
      jsonobj += "field4:";
      jsonobj += f4;
       jsonobj += ",";
      jsonobj += "field5:";
      jsonobj += f5;
      jsonobj += ",";
      jsonobj += "field6:";
      jsonobj += f6;
      jsonobj += ",";
      jsonobj += "field7:";
      jsonobj += f7;
      jsonobj += ",";
      jsonobj += "field8:";
      jsonobj += f8;
      jsonobj += "\"";
      const char* jobj = jsonobj.c_str();
      webSocket.emit("track-data", jobj);
  }
}
void senspark:: collectdata(int mint, float f1, float f2, float f3, float f4, float f5, float f6,float f7, float f8, float f9)
{
  if (millis() - lastMillis >= mint * 60 * 1000UL)
  {
      lastMillis = millis(); 
      String jsonobj = "\"field1:";
      jsonobj += f1;
      jsonobj += ",";
      jsonobj += "field2:";
      jsonobj += f2;
      jsonobj += ",";
      jsonobj += "field3:";
      jsonobj += f3;
      jsonobj += ",";
      jsonobj += "field4:";
      jsonobj += f4;
      jsonobj += ",";
      jsonobj += "field5:";
      jsonobj += f5;
      jsonobj += ",";
      jsonobj += "field6:";
      jsonobj += f6;
      jsonobj += ",";
      jsonobj += "field7:";
      jsonobj += f7;
      jsonobj += ",";
      jsonobj += "field8:";
      jsonobj += f8;
      jsonobj += ",";
      jsonobj += "field9:";
      jsonobj += f9;
      jsonobj += "\"";
      const char* jobj = jsonobj.c_str();
      webSocket.emit("track-data", jobj);
  }
}
void senspark:: collectdata(int mint, float f1, float f2, float f3, float f4, float f5, float f6,float f7, float f8, float f9, float f10)
{
  if (millis() - lastMillis >= mint * 60 * 1000UL)
  {
      lastMillis = millis();
      String jsonobj = "\"field1:";
      jsonobj += f1;
      jsonobj += ",";
      jsonobj += "field2:";
      jsonobj += f2;
      jsonobj += ",";
      jsonobj += "field3:";
      jsonobj += f3;
      jsonobj += ",";
      jsonobj += "field4:";
      jsonobj += f4;
       jsonobj += ",";
      jsonobj += "field5:";
      jsonobj += f5;
      jsonobj += ",";
      jsonobj += "field6:";
      jsonobj += f6;
      jsonobj += ",";
      jsonobj += "field7:";
      jsonobj += f7;
      jsonobj += ",";
      jsonobj += "field8:";
      jsonobj += f8;
      jsonobj += ",";
      jsonobj += "field9:";
      jsonobj += f9;
      jsonobj += ",";
      jsonobj += "field10:";
      jsonobj += f10;
      jsonobj += "\"";
      const char* jobj = jsonobj.c_str();
      webSocket.emit("track-data", jobj);
  }
}
